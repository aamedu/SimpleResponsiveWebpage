var selectedProduct = 0;
var products;
var DOMproductList = $("#products ul.list");
var DomproductFigure = $("figure.product");

$(function() {
    DOMproductList = $("#products ul.list");
    DomproductFigure = $("figure.product");

    $.ajax({
        type: "GET",
        url: "software.xml",
        cache: false,
        dataType: "xml",
        success: function(xml) {
            products = xml;
            loadProductList(xml);
            loadProductFigure(xml);
        }
    });

    if ((navigator.userAgent.indexOf("MSIE")) != -1) {
        alert("Your browser is not supported. Please get a better browser (e.g. Firefox).");
    }
});

function loadProductList(xml) {
    $(xml).find("product").each(function(index) {
        DOMproductList.append(
            "<li class='label' onclick='setProduct(\"" + index + "\");'><img src='../assets/" + $(this).find("icon").text() + "' alt='' title='" + $(this).find("subtitle").text() + "' /><h3>" + $(this).find("title").text() + "</h3></li>"
        );
    });
}

function loadProductFigure(xml) {
    DomproductFigure.html("");
    $(xml).find("product").eq(selectedProduct).each(function() {
        DomproductFigure.append(
            "<img src='../assets/" + $(this).find("thumbnail").text() + "' alt='" + $(this).find("title").text() + "' /><div class='label'><img src='../assets/" + $(this).find("icon").text() + "' alt='' /><h3>" + $(this).find("title").text() + "</h3></div><p class='description'>" + $(this).find("description").text() + "</p><div class='flex-container-h'>"
        );
        $(this).find("download").each(function() {
            $("figure.product .flex-container-h").append(
                "<a class='button btn-inline' href='" + $(this).text() + "' target='_blank'><img src='../assets/" + $(this).attr("platform") + ".png' alt='" + $(this).attr("platform") + "' /></a>"
            );
        });
        DomproductFigure.append("</div>");
    });
}

function previous() {
    selectedProduct--;
    if (selectedProduct >= $(products).find("product").length) {
        selectedProduct = 0;
    } else if (selectedProduct < 0) {
        selectedProduct = $(products).find("product").length - 1;
    }
    loadProductFigure(products);

}

function next() {
    selectedProduct++;
    if (selectedProduct >= $(products).find("product").length) {
        selectedProduct = 0;
    } else if (selectedProduct < 0) {
        selectedProduct = $(products).find("product").length - 1;
    }
    loadProductFigure(products);
}

function setProduct(index) {
    selectedProduct = index;
    loadProductFigure(products);
}