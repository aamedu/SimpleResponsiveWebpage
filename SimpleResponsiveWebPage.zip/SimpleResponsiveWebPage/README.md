# SimpleResponsiveWebpage
A Simple Responsive WebPage HTML CSS


Assumptions and Solutions

1. The mobile web is important (Design mobile first).

2. Create once, publish everywhere.

3. Editorial workflow is important

4. Make existential design decisions based on data,  not assumptions.

5. Design from content outward (not device type or display inward).

6. Nothing's more important than knowing what's important ie.
a. People will know how to find your website
b. People know what you sell
c. Everything will go as planned
d. People know where to click
e. People know how to get home
f. People know where they are
g. People know how to buy
h. People will volunteer loads of personal information
g. People will contact customer service if they have a question or problem
h. People will come back

7. Optimize, then customize.

8. Creating and maintaining a visual language (NOT a myriad of distinct designs).
