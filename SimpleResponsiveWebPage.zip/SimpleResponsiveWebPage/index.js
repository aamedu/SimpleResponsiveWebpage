var productsSoftware, productsGames;
var DomproductFigureSoftware = $("#software figure.product");
var DomproductFigureGames = $("#games figure.product");

$(function() {
    DomproductFigureSoftware = $("#software figure.product");
    DomproductFigureGames = $("#games figure.product");

    $.ajax({
        type: "GET",
        url: "software/software.xml",
        cache: false,
        dataType: "xml",
        success: function(xmlSoftware) {
            loadProductFigure(xmlSoftware, DomproductFigureSoftware);
        }
    });

    $.ajax({
        type: "GET",
        url: "games/games.xml",
        cache: false,
        dataType: "xml",
        success: function(xmlGames) {
            loadProductFigure(xmlGames, DomproductFigureGames);
        }
    });

    if ((navigator.userAgent.indexOf("MSIE")) != -1) {
        alert("Your browser is not supported. Please get a better browser (e.g. Firefox).");
    }
});

function loadProductFigure(xml, DomproductFigure) {
    DomproductFigure.html("");
    $(xml).find("product").eq(0).each(function() {
        DomproductFigure.append(
            "<img src='assets/" + $(this).find("thumbnail").text() + "' alt='placeholder thumbnail'/><div class='label'><img src='assets/" + $(this).find("icon").text() + "' alt=''/><h3>" + $(this).find("title").text() + "</h3></div>"
        );
    });
}